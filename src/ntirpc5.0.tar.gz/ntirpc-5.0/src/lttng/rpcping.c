#define TRACEPOINT_CREATE_PROBES
#include "lttng/rpcping.h"
